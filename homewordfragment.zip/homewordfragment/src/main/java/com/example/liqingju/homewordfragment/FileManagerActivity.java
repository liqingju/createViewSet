package com.example.liqingju.homewordfragment;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by liqingju on 16/2/20.
 */
public class FileManagerActivity  extends Activity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.secondfragment);
    }
}
